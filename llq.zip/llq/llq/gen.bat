@echo off  
setlocal enabledelayedexpansion  
